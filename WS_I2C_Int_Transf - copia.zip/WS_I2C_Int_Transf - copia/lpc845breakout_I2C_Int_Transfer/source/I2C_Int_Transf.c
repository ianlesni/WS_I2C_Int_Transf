/*
 * Copyright 2019 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "fsl_i2c.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define BOARD_LED_PORT BOARD_LED_RED_PORT
#define BOARD_LED_PIN  BOARD_LED_RED_PIN

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint32_t g_systickCounter;

const uint8_t slave_address = 0x40;
int16_t datos_js_1;

struct _i2c_master_transfer xfer = {
    .flags = kI2C_TransferDefaultFlag,
    .slaveAddress = slave_address,
    .direction = kI2C_Read,
    .data = &datos_js_1,
    .dataSize = sizeof(datos_js_1),
    .subaddress = 0,
    .subaddressSize = 0,
};

i2c_master_handle_t handle;

int16_t datos_js_1 = 0; //datos recibidos
int8_t X_js_1 = 0;		 //coordenadas en X
int8_t Y_js_1 = 0;		 //coordenadas en Y

/*******************************************************************************
 * Code
 ******************************************************************************/
void myI2CCallback(I2C_Type *base, i2c_master_handle_t *handle, status_t completionStatus,void *userData)
{
    uint32_t status;

    /* Check the status of the transfer. */
    status = completionStatus;
    if (status == kStatus_Success)
    {
        /* Transfer completed successfully. */
    	Y_js_1 = (int8_t)(((datos_js_1) >> 8) & 0xFF);
    	X_js_1 = (int8_t)((datos_js_1) & 0xFF);

    }
    else if (status == kStatus_I2C_Timeout)
    {
    	while(1){}   /* Transfer timed out. */
    }
    else if (status == kStatus_I2C_Nak)
    {
    	while(1){}   /* Slave device did not acknowledge the transfer. */
    }
    else if (status == kStatus_I2C_UnexpectedState)
    {
    	while(1){}   /* Bus error occurred during the transfer. */
    }
}

void SysTick_Handler(void)
{
    if (g_systickCounter != 0U)
    {
        g_systickCounter--;
    }
}

void SysTick_DelayTicks(uint32_t n)
{
    g_systickCounter = n;
    while (g_systickCounter != 0U)
    {
    }
}

/*!
 * @brief Main function
 */
int main(void)
{
    /* Init output LED GPIO. */
    GPIO_PortInit(GPIO, BOARD_LED_PORT);

    /* Board pin init */
    BOARD_InitPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();

    I2C_MasterTransferCreateHandle(I2C1, &handle, myI2CCallback,NULL);
    /*Comienzo transferencia */
    I2C_MasterTransferNonBlocking(I2C1, &handle, &xfer);

    /* Set systick reload value to generate 1ms interrupt */
    if (SysTick_Config(SystemCoreClock / 1000U))
    {
        while (1)
        {
        }
    }

    while (1)
    {
        /* Delay 1000 ms */
        SysTick_DelayTicks(1000U);
        I2C_MasterTransferNonBlocking(I2C1, &handle, &xfer);
        GPIO_PortToggle(GPIO, BOARD_LED_PORT, 1u << BOARD_LED_PIN);
    }
}
